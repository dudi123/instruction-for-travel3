<template>
  
  <v-container>

    <v-list v-if="startup">
      <v-list-item v-for="item in startup.userProfile" :title="item.id" :subtitle="item.value" />
    </v-list>

  </v-container>

</template>

<script setup>
import { onMounted, ref } from 'vue';
import { getStartup } from '@/core/api';


const startup = ref(null);

onMounted(async () => {
  const { data } = await getStartup();
  startup.value = data;
}); 

</script>
