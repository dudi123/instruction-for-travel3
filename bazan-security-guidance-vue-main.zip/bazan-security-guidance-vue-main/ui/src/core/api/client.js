import axios from "axios";

const baseURL = 'GWD_DEPLOY_HTML5/sap/bc/ui2'

//// const baseURL = "GWD_DEPLOY_HTML5/sap/opu/odata/sap/ZSECURITY_INSTRUCTIONS_SRV";

const instance = axios.create({
  baseURL,
});

export default instance;